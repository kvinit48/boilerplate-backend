package com.example.boilerplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoilerplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
